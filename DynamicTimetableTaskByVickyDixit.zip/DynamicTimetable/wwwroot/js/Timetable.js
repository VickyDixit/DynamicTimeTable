﻿function printTimetable() {
    var printContent = document.getElementById('printSection').innerHTML;
    var originalContent = document.body.innerHTML;

    document.body.innerHTML = printContent;
    window.print();
    document.body.innerHTML = originalContent;
}